#Encryptor for week 2
import random 

filename = input("Enter Source Filename: ")
fileIn = open(filename, "r")
fileOut = open("encrypted.txt", "w")
key = input("Enter new key: ")

alphabet = list("abcdefghijklmnopqrstuvwxyz")
random.Random(key).shuffle(alphabet)
alternate = alphabet
alphabet = list("abcdefghijklmnopqrstuvwxyz")

keys = alphabet
values = alternate
cypher = dict(zip(keys, values))

outputText = ""
for char in fileIn.read().lower():
	if char in alphabet:
		key = char
		outputText += cypher[key]
	else:
		outputText += char

fileOut.write(outputText)

print("See encrypted.txt")